//
//  InMoment.h
//  InMoment
//
//  Created by Kyler Jensen on 8/17/16.
//  Copyright © 2016 InMoment, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for InMoment.
FOUNDATION_EXPORT double InMomentVersionNumber;

//! Project version string for InMoment.
FOUNDATION_EXPORT const unsigned char InMomentVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <InMoment/PublicHeader.h>


